# FurBot Discord
An e621 search bot, inspired by furbot from /r/furry_irl (Join our [Discord Server!](https://discordapp.com/invite/YTEeY9g))  
<p align="center">
  <img alt="Preview" src="https://puu.sh/zeVRk/f06f04120f.png">
</p>

## Requirements
1. Python 3.5+
2. `requests`
3. https://www.github.com/Rapptz/discord.py  - rewrite

## Using this bot
Available [Here](https://furbot.rorre.me/command)  

## Contributing
Thanks for your interest in contributing!  
Feel free to create a fork and create a Pull Request with your changes!
